readme.txt - Information for IrfanView ZIP users


*** IMPORTANT INFO !!! ***


Please start IrfanView and call (once) any of the dialogs:

- Properties (P), or
- File->Open (O), or
- File->Save As (S), or
- Batch (B)


to convert/set IrfanView INI file to UNICODE mode !


If the INI file is not converted to Unicode, some of the options (like filenames, paths or text options) 
may NOT be saved properly and the feature may not be working as expected.
----
